`1.1.0`
-------

- Added storage settings

`1.0.0`
-------

- Init version
